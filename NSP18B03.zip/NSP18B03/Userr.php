<!DOCTYPE html>
<html>
<head>
	<title>Admin Page</title>
	 <link rel="stylesheet" href="js/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <style type="text/css">
  	input[type=text], input[type=number], input[type=date], input[type=comment]
  	{
  		width: 100%;height: 50px;
  		border-radius: 15px;border-top: 0px;border-right: 0px;opacity: .7;
  	}
  </style>
</head>
<body>
<div class="container-fliud">
	<div class="well">
		<?php 
			$servername="localhost";
$username="root";
$password="";
$dbname="event";
$conn=mysqli_connect($servername,$username,$password,$dbname);
$sql="select * from signup";
$result=mysqli_query($conn,$sql);
  if (mysqli_num_rows($result)) {?>
  	<table border="3">
  		<tr>
  			<th>name</th>
  		</tr>
    <?php while($row=mysqli_fetch_assoc($result)){
		 ?>
		 <tr>
		 	<td><?php echo $row['fname']; ?></td>
		 </tr>
		 <?php } }?>
</table></div>
	</div>
</div>
</body>
</html>