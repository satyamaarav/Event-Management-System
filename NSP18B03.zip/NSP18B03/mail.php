
<?php
// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require 'vendor/autoload.php';

$mail = new PHPMailer(true);                              // Passing `true` enables exceptions
try {
   //Server settings
    $mail->SMTPDebug = 2;                                 // Enable verbose debug output
    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = 'satyamranjan4035@gmail.com';                 // SMTP username
    $mail->Password = 'satyamonly';                           // SMTP password
    $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 465;                                    // TCP port to connect to

    //Recipients
    $mail->setFrom('satyamranjan4035@gmail.com', 'Event Management System');
    $mail->addAddress('2017pietcssatyam096@poornima.org', 'satyam');     // Add a recipient
    //$mail->addAddress('@gmail.com');               // Name is optional
    $mail->addReplyTo('kruti@poornima.org', 'Information');
    //$mail->addCC('cc@example.com');
    //$mail->addBCC('bcc@example.com');

    //Attachments
    //$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
    //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

    //Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'Here is the subject';
    $mail->Body    = 'This is the HTML message body <b>in bold!</b>';
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
    echo $a=$_POST['inputfname3'];
$b=$_POST['inputlname3'];
$c=$_POST['inputDate3'];
$d=$_POST['inputmobile3'];
$e=$_POST['inputadhar3'];
$f=$_POST['inputEmail3'];
$g=$_POST['inputPassword3'];
$h=$_POST['inputaddress3'];
$servername="localhost";
$username="root";
$password="";
$dbname="event";
$conn=mysqli_connect($servername,$username,$password,$dbname);
$sql="INSERT INTO `signup`(`fname`, `lname`, `birthday`, `mobile`, `adharno`, `email`, `password`, `address`) VALUES ('$a','$b','$c','$d','$e','$f','$g','$h')";
if(mysqli_query($conn,$sql))
{   $_SESSION["FNAME"]=$a;$_SESSION["LNAME"]=$b;$_SESSION["DATE"]=$c;$_SESSION["MOB"]=$d;$_SESSION["ADHAR"]=$e;$_SESSION["EMAIL"]=$f;$_SESSION["ADDRESS"]=$g;
    echo"<script> alert ('account created successfully');
          window.location.assign('index.php')</script>";
}
else
{
    echo"not";
}
mysqli_close($conn);
;
} catch (Exception $e) {
    echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
}
?>