<?php
$a=$_POST['event'];
$b=$_POST['venue'];
$c=$_POST['date'];
$d=$_POST['city'];
$e=$_POST['organiser'];
$f=$_POST['mobile'];
$g=$_POST['details'];
$servername="localhost";
$username="root";
$password="";
$dbname="db_users";
$conn=mysqli_connect($servername,$username,$password,$dbname);
$sql="INSERT INTO `admin`(`name`, `location`, `date`, `city`, `organizer`, `mobile`, `comment`) VALUES ('$a','$b','$c','$d','$e','$f','$g')";
if(mysqli_query($conn,$sql))
{ 	

	echo"<script> alert ('account created successfully');
	      window.location.assign('index.php')</script>";
}
else
{
	echo"not";
}
mysqli_close($conn);
?>