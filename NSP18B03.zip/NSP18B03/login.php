<?php 
session_start();
$a=$_POST['inputEmail3'];
$b=$_POST['inputPassword3'];
$servername="localhost";
$username="root";
$password="";
$dbname="event";
$conn=mysqli_connect($servername,$username,$password,$dbname);

$sql="select * from signup where email='$a' && password='$b'";
$result=mysqli_query($conn,$sql);
	if (mysqli_num_rows($result)) {
		$row=mysqli_fetch_assoc($result);
	 $_SESSION["name"]=$row["fname"];
	 $_SESSION["TYPE"]=$row["type"];
		header('location:index.php');
	}
	else
		echo "<script>alert('Invalid id or password');</script>";
echo "<script>window.location.assign('index.php')</script>";
	      
 ?>