<?php
  session_start();
    ?>
  <!DOCTYPE html>
  <html lang="en">
  <head>
    <title>Home page</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="js/bootstrap.min.css">
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

  </head><style>
  input[type=text],[type=submit],[type=date]
  {margin-top: 20%;
    height: 70px;width: 200px;
    padding: 20px;outline:none;

  }
  body {
    margin: 0;
    font-family: Arial, Helvetica, sans-serif;
  }
  .container{
    max-width: 1000px;
  }
  .header {
      padding: 30px;
      text-align: center;
      background: #1abc9c;
      color: white;
  }

  .topnav {
    overflow: hidden;
    background-color: #333;
  }

  .topnav a {
    float: left;
    display: block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    font-size: 17px;
  }

  .topnav a:hover {
    background-color: #ddd;
    color: black;
  }

  .active {
    background-color: #4CAF50;
    color: white;
  }

  .topnav .icon {
    display: none;
  }

  @media screen and (max-width: 600px) {
    .topnav a:not(:first-child) {display: none;}
    .topnav a.icon {
      float: right;
      display: block;
    }
  }

  @media screen and (max-width: 600px) {
    .topnav.responsive {position: relative;}
    .topnav.responsive .icon {
      position: absolute;
      right: 0;
      top: 0;
    }
    .topnav.responsive a {
      float: none;
      display: block;
      text-align: left;
    }
  }
  h2 {
      color: white;
      text-shadow: 1px 1px 2px black, 0 0 25px blue, 0 0 5px darkblue;
  }
  h1 {
      color: white;
      text-shadow: 2px 2px 4px #000000;
  }
  h1 {
      text-shadow: 0 0 3px #FF0000;
  }
  body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}
.container{
  max-width: 4000px;
}
.header {
    padding: 30px;
    text-align: center;
    background: #1abc9c;
    color: white;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}
.thumbnail:hover {
    -ms-transform: scale(1.5); /* IE 9 */
    -webkit-transform: scale(1.5); /* Safari 3-8 */
    transform: scale(1.5); 
      }
.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.active {
  background-color: #4CAF50;
  color: white;
}

.topnav .icon {
  display: none;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
}

  </style>
  </head>
  <body>

  <script>
  function myFunction() {
      var x = document.getElementById("myTopnav");
      if (x.className === "topnav") {
          x.className += " responsive";
      } else {
          x.className = "topnav";
      }
  }
 function validation(){ 

    var inputfname3 = document.getElementById('inputfname3').value;
    {
      if(inputfname3 ==""){
      return false;
    }
    if((inputfname3.length <=4) || (inputfname3.length> 30)){
      document.getElementById('inputfname3').innerHTML="** user length mustbe 3 to 29" ;
      return false;
    }
    if(!isNaN(inputfname3)){
      return false;
    }
}
var inputlname3 = document.getElementById('inputlname3').value;
    {

      if(inputlname3 ==""){
      return false;
    }
    if((inputlname3.length <=4) || (inputlname3.length> 30)){
      document.getElementById('inputlname3').innerHTML="** user length mustbe 3 to 29" ;
      return false;
    }
    if(!isNaN(inputlname3)){
      document.getElementById('inputlname3').innerHTML="** only characters are allowed " ;
      return false;

}
}

var inputaddress3 = document.getElementById('inputaddress3').value;
    {

      if(inputaddress3 ==""){
      return false;
    }
    if((inputaddress3.length <=4) || (inputaddress3.length> 100)){
      document.getElementById('inputaddress3').innerHTML="** user length mustbe 3 to 100" ;
      return false;
    }
    if(!isNaN(inputaddress3)){
      document.getElementById('inputaddress3').innerHTML="** only characters are allowed " ;
      return false;

}
}
}
  </script>


  <div class="container-fluid">
    <div class="row">

      <div class="navbar navbar-inverse navbar-fixed-top " style="background-color: white;font-size: 18px">

        <ul class="nav nav-tabs">
         
      <li ><a href="index.php" style="margin-top: 50px">Home</a></li>
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#" style="margin-top: 50px">Event<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="eventlist.php">Event list</a></li>
          <li><a href="event.php">Event venue</a></li>                      
        </ul>
      </li>
     <li><a href="services.php" style="margin-top: 50px">Services</a></li>
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#" style="margin-top: 50px">Gallery<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="gwed.php">Wedding</a></li>
          <li><a href="gbirth.php">Birthday</a></li>
          <li><a href="gmusic.php">Music-concerts</a></li>
          <li><a href="gconf.php">Conference</a></li>
 
          <li><a href="gbusi.php">Business Meetings</a></li>
          <li><a href="genag.php">Engagements</a></li>                        
        </ul>
      </li>
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#" style="margin-top: 50px">Pages<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="pdetail.php">Detail page</a></li>
          <li><a href="#">My Profile</a></li>
          <li><a href="#">Edit profile</a></li>
          <li><a href="pblog.php">Blog</a></li>   
          <li><a href="privacy.php">Privacy policy</a></li> 
          <li><a href="piechart.php">Chart</a></li> 
          <li><a href="pteam.php">Team</a></li>                       
        </ul>
      </li>
      <li><a href="booknow.php" style="margin-top: 50px">Book Now</a></li>
      <li><a href="about.php" style="margin-top: 50px">About us</a></li>
      <li><a href="faq.php" style="margin-top: 50px">FAQ'S</a></li>
      <li><a href="contact.php" style="margin-top: 50px">Contact us</a></li>
      <?php if(!empty($_SESSION["name"])) { 
          echo "<li><a>".$_SESSION["name"]."</a></li>";
          echo "<li><a href='logout.php'>Logout</a></li>";
        if($_SESSION["TYPE"]=="admin"){
       echo "<li><a href='admin.php'>Admin</a></li>";
        } }else{
        ?>
      <li><a data-toggle="modal" data-target="#myModal" data-backdrop="false" style="margin-left:400px ">
      Login
    </a>

  
    <!-- The Modal -->
    <div class="modal fade" id="myModal">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
        
          <!-- Modal Header -->
            <div class="modal-header">
                  <button type="button" class="close" 
                     data-dismiss="modal">
                         <span aria-hidden="true">&times;</span>
                         <span class="sr-only">Close</span>
                  </button>
                 <center> <h4 class="modal-title" id="myModalLabel">
                      Login
                  </h4></center>
              </div>
              
              <!-- Modal Body -->
              <div class="modal-body">
                  
                  <form action="login.php" method="POST" class="form-horizontal" role="form">
                    <div class="form-group">
                      <label  class="col-sm-3 control-label"
                                for="inputEmail3">Email</label>
                      <div class="col-sm-7">
                          <input type="email" class="form-control" 
                          id="inputEmail3" name="inputEmail3" placeholder="Email" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-3 control-label"
                            for="inputPassword3" >Password</label>
                      <div class="col-sm-7">
                          <input type="password" class="form-control"
                              id="inputPassword3" name="inputPassword3" placeholder="Password" required>
                      </div>
                    </div>
                    

                    <div class="form-group">
                      <div class="col-sm-offset-2 col-sm-10">
                        <div class="checkbox">
                          <label>
                              <input type="checkbox"/> Remember me
                          </label>
                        </div>
                      </div>
                    </div>              
              <?php
  //Include GP config file && User class
  include_once 'gpConfig.php';
  include_once 'User.php';

  if(isset($_GET['code'])){
    $gClient->authenticate($_GET['code']);
    $_SESSION['token'] = $gClient->getAccessToken();
    header('Location: ' . filter_var($redirectURL, FILTER_SANITIZE_URL));
  }

  if (isset($_SESSION['token'])) {
    $gClient->setAccessToken($_SESSION['token']);
  }

  if ($gClient->getAccessToken()) {
    //Get user profile data from google
    $gpUserProfile = $google_oauthV2->userinfo->get();
    
    //Initialize User class
    $user = new User();
    
    //Insert or update user data to the database
      $gpUserData = array(
          'oauth_provider'=> 'google',
          'oauth_uid'     => $gpUserProfile['id'],
          'first_name'    => $gpUserProfile['given_name'],
          'last_name'     => $gpUserProfile['family_name'],
          'email'         => $gpUserProfile['email'],
          'gender'        => $gpUserProfile['gender'],
          'locale'        => $gpUserProfile['locale'],
          'picture'       => $gpUserProfile['picture'],
          'link'          => $gpUserProfile['link']
      );
      $userData = $user->checkUser($gpUserData);
    
    //Storing user data into session
    $_SESSION['userData'] = $userData;
    
    //Render facebook profile data
      if(!empty($userData)){
          $output = '<h1>Google+ Profile Details </h1>';
          $output .= '<img src="'.$userData['picture'].'" width="300" height="220">';
          $output .= '<br/>Google ID : ' . $userData['oauth_uid'];
          $output .= '<br/>Name : ' . $userData['first_name'].' '.$userData['last_name'];
          $output .= '<br/>Email : ' . $userData['email'];
          $output .= '<br/>Gender : ' . $userData['gender'];
          $output .= '<br/>Locale : ' . $userData['locale'];
          $output .= '<br/>Logged in with : Google';
          $output .= '<br/><a href="'.$userData['link'].'" target="_blank">Click to Visit Google+ Page</a>';
          $output .= '<br/>Logout from <a href="logout.php">Google</a>'; 
      }else{
          $output = '<h3 style="color:red">Some problem occurred, please try again.</h3>';
      }
  } else {
    $authUrl = $gClient->createAuthUrl();
    $output = '<a href="'.filter_var($authUrl, FILTER_SANITIZE_URL).'"><img src="images/glogin.png" alt=""/ style="height:150px;width:300px;margin-left:100px"></a>';
   
  }
  ?>
  <html>
  <head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Login with Google using PHP by CodexWorld</title>
  <style type="text/css">
  h1{font-family:Arial, Helvetica, sans-serif;color:#999999;}
  </style>
  </head>
  <body>
  <div><?php echo $output; ?></div>
  </body>
  </html></div>
          <a href="forget.php">Forget Password</a>
          <!-- Modal footer -->
          <div class="modal-footer">
            <div class="col-sm-1">
           <input type="submit" name="signup">
         </div>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          </div></form>
          
        </div>
      </div>
    </div></li>
    <li><a data-toggle="modal" data-target="#mysignup" data-backdrop="false">
      Sign Up
    </a>

    <!-- The Modal -->
    <div class="modal fade" id="mysignup">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
        
          <!-- Modal Header -->
            <div class="modal-header">
                  <button type="button" class="close" 
                     data-dismiss="modal">
                         <span aria-hidden="true">&times;</span>
                         <span class="sr-only">Close</span>
                  </button>
                  <center><h4 class="modal-title" id="myModalLabel">
                      Sign Up
                  </h4></center>
              </div>
              
              <!-- Modal Body -->
              <div class="modal-body">
 <form class="form-horizontal" name="f1" role="form" action="signup.php" method="POST" onsubmit="return validation()">
                    <div class="form-group">
                      <label  class="col-sm-3 control-label"
                                for="inputText3">First Name</label>
                      <div class="col-sm-9">
                          <input type="inputText3" class="form-control" 
                          id="inputfname3" name="inputfname3" placeholder="First Name" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-3 control-label"
                            for="inputtext3" >Last Name</label>
                      <div class="col-sm-9">
                          <input type="inputText3" class="form-control"
                              id="inputlname3"  name="inputlname3" placeholder="Last Name" required>
                      </div>
                    </div>
                    
                    <div class="form-group">
                      <label class="col-sm-3 control-label"
                            for="inputdate3" >Birthday</label>
                      <div class="col-sm-9">
                          <input type="inputdate3" class="form-control"
                              id="inputdate3" id="inputDate3" placeholder="mm/dd/yy" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-3 control-label"
                            for="inputtext3" >Mobile No.</label>
                      <div class="col-sm-9">
                          <input type="inputtext3" class="form-control"
                              id="inputmobile3" name="inputmobile3" placeholder="Mobile No." required maxlength="10" minlength="10">
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-3 control-label"
                            for="inputtext3" >Adhar No.</label>
                      <div class="col-sm-9">
                          <input type="inputext3" class="form-control"
                              id="inputadhar3" placeholder="Adhar No." minlength="16" maxlength="16" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-3 control-label"
                            for="email" >Email</label>
                      <div class="col-sm-9">
                          <input type="email" class="form-control"
                              id="inputEmail3"  name="inputEmail3" placeholder="Email" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-3 control-label"
                            for="inputPassword3" >Password</label>
                      <div class="col-sm-9">
                          <input type="password" class="form-control"
                              id="inputPassword3"  name="inputPassword3" placeholder="Password"  maxlength="16" minlength="6" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-3 control-label"
                            for="inputtext3" >Address</label>
                      <div class="col-sm-9">
                          <input type="inputText3" class="form-control"
                              id="inputaddress3" name="inputaddress3" placeholder="Address" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="col-sm-offset-2 col-sm-10">
                        <div class="checkbox">
                          <label>
                              <input type="checkbox"/> Remember me
                          </label>
                        </div>
                      </div>
                    </div>              
              </div>
          
          <!-- Modal footer -->
          <div class="modal-footer">
            <div class="col-sm-1">
           <input type="submit" name="signup">
         </div>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          </div></form>
          
        </div>
      </div>
    </div></li>
    </ul>
  </div>

      </div><?php } ?>
      
    </div>

  </div><br><br><br><br><br><br>
  <div class="row"><br><br>
    <div class="col-md-4 col-md-offset-1" style="height: 150px;width: 300px;">
      <div class="thumbnail">
        <a href="image/e1.jpg" target="_blank">
          <img src="image/e1.jpg" alt="Lights" style="height: 150px;width:100%">
        </a>
      </div>
    </div>
    <div class="col-md-4 col-md-offset-1" style="height: 150px;width: 300px;">
      <div class="thumbnail">
        <a href="image/e2.jpg" target="_blank">
          <img src="image/e2.jpg" alt="Nature" style="height: 150px;width:100%">
          </a>
      </div>
    </div>
    <div class="col-md-4 col-md-offset-1" style="height: 150px;width: 300px;">
      <div class="thumbnail">
        <a href="image/e3.jpg" target="_blank">
          <img src="image/e3.jpg" alt="Fjords" style="height: 150px;width:100%">
          </a>
      </div>
    </div>
  </div><br><br>
  <div class="row">
    <div class="col-md-4 col-md-offset-1" style="height: 150px;width: 300px;">
      <div class="thumbnail">
        <a href="image/e4.jpg" target="_blank">
          <img src="image/e4.jpg" alt="Lights" style="height: 150px;width:100%">
           </a>
      </div>
    </div>
    <div class="col-md-4 col-md-offset-1" style="height: 150px;width: 300px;">
      <div class="thumbnail">
        <a href="image/e5.jpg" target="_blank">
          <img src="image/e5.jpg" alt="Nature" style="height: 150px;width:100%">
          </a>
      </div>
    </div>
    <div class="col-md-4 col-md-offset-1" style="height: 150px;width: 300px;">
      <div class="thumbnail">
        <a href="image/e6.jpg" target="_blank">
          <img src="image/e6.jpg" alt="Fjords" style="height: 150px;width:100%">
          </a>
      </div>
    </div>
  </div><br><br>
<div class="row">
    <div class="col-md-4 col-md-offset-1" style="height: 150px;width: 300px;">
      <div class="thumbnail">
        <a href="image/e7.jpg" target="_blank">
          <img src="image/e7.jpg" alt="Lights" style="height: 150px;width:100%">
          </a>
      </div>
    </div>
    <div class="col-md-4 col-md-offset-1" style="height: 150px;width: 300px;">
      <div class="thumbnail">
        <a href="image/e8.jpg" target="_blank">
          <img src="image/e8.jpg" alt="Nature" style="height: 150px;width:100%">
          </a>
      </div>
    </div>
    <div class="col-md-4 col-md-offset-1" style="height: 150px;width: 300px;">
      <div class="thumbnail">
        <a href="image/e9.jpg" target="_blank">
          <img src="image/e9.jpg" alt="Fjords" style="height: 150px;width:100%">
          </a>
      </div>
    </div>
  </div><br><br>
<div class="row">
    <div class="col-md-4 col-md-offset-1" style="height: 150px;width: 300px;">
      <div class="thumbnail">
        <a href="image/e10.jpg" target="_blank">
          <img src="image/e10.jpg" alt="Lights" style="height: 150px;width:100%">
      </a>
      </div>
    </div>
    <div class="col-md-4 col-md-offset-1" style="height: 150px;width: 300px;">
      <div class="thumbnail">
        <a href="image/e11.jpg" target="_blank">
          <img src="image/e11.jpg" alt="Nature" style="height: 150px;width:100%">
          </a>
      </div>
    </div>
    <div class="col-md-4 col-md-offset-1" style="height: 150px;width: 300px;">
      <div class="thumbnail">
        <a href="image/e12.jpg" target="_blank">
          <img src="image/e12.jpg" alt="Fjords" style="height: 150px;width:100%">
           </a>
      </div>
    </div>
  </div><br><br>
  <div class="row">
    <div class="col-md-4 col-md-offset-1" style="height: 150px;width: 300px;">
      <div class="thumbnail">
        <a href="image/e13.jpg" target="_blank">
          <img src="image/e13.jpg" alt="Lights" style="height: 150px;width:100%">
        </a>
      </div>
    </div>
    <div class="col-md-4 col-md-offset-1" style="height: 150px;width: 300px;">
      <div class="thumbnail">
        <a href="image/e14.jpg" target="_blank">
          <img src="image/e14.jpg" alt="Nature" style="height: 150px;width:100%">
          </a>
      </div>
    </div>
    <div class="col-md-4 col-md-offset-1" style="height: 150px;width: 300px;">
      <div class="thumbnail">
        <a href="image/e15.jpg" target="_blank">
          <img src="image/e15.jpg" alt="Fjords" style="height: 150px;width:100%">
          </a>
      </div>
    </div>
  </div><br><br>
  <div class="row">
    <div class="col-md-4 col-md-offset-1" style="height: 150px;width: 300px;">
      <div class="thumbnail">
        <a href="image/e16.jpg" target="_blank">
          <img src="image/e16.jpg" alt="Lights" style="height: 150px;width:100%">
           </a>
      </div>
    </div>
    <div class="col-md-4 col-md-offset-1" style="height: 150px;width: 300px;">
      <div class="thumbnail">
        <a href="image/e17.jpg" target="_blank">
          <img src="image/e17.jpg" alt="Nature" style="height: 150px;width:100%">
          </a>
      </div>
    </div>
    <div class="col-md-4 col-md-offset-1" style="height: 150px;width: 300px;">
      <div class="thumbnail">
        <a href="image/e18.jpg" target="_blank">
          <img src="image/e18.jpg" alt="Fjords" style="height: 150px;width:100%">
          </a>
      </div>
    </div>
    </div><br><br>
      <div class="row">
    <div class="col-md-4 col-md-offset-1" style="height: 150px;width: 300px;">
      <div class="thumbnail">
        <a href="image/e19.jpg" target="_blank">
          <img src="image/e19.jpg" alt="Lights" style="height: 150px;width:100%">
        </a>
      </div>
    </div>
    <div class="col-md-4 col-md-offset-1" style="height: 150px;width: 300px;">
      <div class="thumbnail">
        <a href="image/e20.jpg" target="_blank">
          <img src="image/e20.jpg" alt="Nature" style="height: 150px;width:100%">
          </a>
      </div>
    </div>
    <div class="col-md-4 col-md-offset-1" style="height: 150px;width: 300px;">
      <div class="thumbnail">
        <a href="image/e21.jpg" target="_blank">
          <img src="image/e21.jpg" alt="Fjords" style="height: 150px;width:100%">
          </a>
      </div>
    </div>
  </div><br><br>
  <div class="row">
    <div class="col-md-4 col-md-offset-1" style="height: 150px;width: 300px;">
      <div class="thumbnail">
        <a href="image/e22.jpg" target="_blank">
          <img src="image/e22.jpg" alt="Lights" style="height: 150px;width:100%">
           </a>
      </div>
    </div>
    <div class="col-md-4 col-md-offset-1" style="height: 150px;width: 300px;">
      <div class="thumbnail">
        <a href="image/e23.jpg" target="_blank">
          <img src="image/e23.jpg" alt="Nature" style="height: 150px;width:100%">
          </a>
      </div>
    </div>
    <div class="col-md-4 col-md-offset-1" style="height: 150px;width: 300px;">
      <div class="thumbnail">
        <a href="image/e24.jpg" target="_blank">
          <img src="image/e24.jpg" alt="Fjords" style="height: 150px;width:100%">
          </a>
      </div>
    </div>
  </div><br><br>
<div class="row">
    <div class="col-md-4 col-md-offset-1" style="height: 150px;width: 300px;">
      <div class="thumbnail">
        <a href="image/e25.jpg" target="_blank">
          <img src="image/e25.jpg" alt="Lights" style="height: 150px;width:100%">
          </a>
      </div>
    </div>
    <div class="col-md-4 col-md-offset-1" style="height: 150px;width: 300px;">
      <div class="thumbnail">
        <a href="image/e26.jpg" target="_blank">
          <img src="image/e26.jpg" alt="Nature" style="height: 150px;width:100%">
          </a>
      </div>
    </div>
    <div class="col-md-4 col-md-offset-1" style="height: 150px;width: 300px;">
      <div class="thumbnail">
        <a href="image/e27.jpg" target="_blank">
          <img src="image/e27.jpg" alt="Fjords" style="height: 150px;width:100%">
          </a>
      </div>
    </div>
  </div><br><br>

 <div class="row well" style="background-color: grey;">  
      <div class="col-sm-3 well" style="background-color: grey; font-size: 18px; color: white ;border:none;border-right: 2px solid;height: 300px;">Disclaimer <br>FAQ <br> Terms & Condition <br> About Us <br> Privacy Policy</div>
      <div class="col-sm-3 col-sm-offset-1 well" style="background-color: grey; height: 300px;font-size: 18px; color: white;border:none;border-right: 2px solid;"><u style="font-size: 20px;">Follow Us On</u><br>Facebook <br>Instagram <br> Google+<br> Twitter</div>
      <div class="col-sm-3 col-sm-offset-2 well" style="background-color: grey; font-size: 18px;height: 300px; color: white;border:none;border-right: 2px solid;">
        Event Management System <br> 13/14 Saraswati Bihar,Goner Phtak <br> Jaipur city,302022 <br> Distt. Jaipur <br> Rajasthan <br>E-mail:-kaleidoscope@gmail.com <br>Contact No:- 1234567890
      </div>
</div>

</body>
</html>


