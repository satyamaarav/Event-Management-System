<?php
session_start();
if(!empty($_SESSION["name"]))
{
	header('location:index.php');
}
else{
$a=$_POST['inputfname3'];
$b=$_POST['inputlname3'];
$c=$_POST['inputDate3'];
$d=$_POST['inputmobile3'];
$e=$_POST['inputadhar3'];
$f=$_POST['inputEmail3'];
$g=$_POST['inputPassword3'];
$h=$_POST['inputaddress3'];
$servername="localhost";
$username="root";
$password="";
$dbname="event";
$conn=mysqli_connect($servername,$username,$password,$dbname);
$sql="INSERT INTO `signup`(`fname`, `lname`, `birthday`, `mobile`, `adharno`, `email`, `password`, `address`,`type`) VALUES ('$a','$b','$c','$d','$e','$f','$g','$h','client')";
if(mysqli_query($conn,$sql))
{ 	$_SESSION["FNAME"]=$a;$_SESSION["LNAME"]=$b;$_SESSION["DATE"]=$c;$_SESSION["MOB"]=$d;$_SESSION["ADHAR"]=$e;$_SESSION["EMAIL"]=$f;$_SESSION["ADDRESS"]=$g;
	echo"<script> alert ('account created successfully');
	      window.location.assign('index.php')</script>";
}
else
{
	echo"not";
}
mysqli_close($conn);
}
?>